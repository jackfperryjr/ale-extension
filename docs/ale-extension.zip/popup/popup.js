async function init() {
  const session = await chrome.runtime.sendMessage({ type: 'GET_SESSION' });
  renderAuth(session);
  if (session) {
    chrome.runtime.sendMessage({ type: 'REFRESH_SESSION' }, (fresh) => {
      if (fresh && !fresh.error) renderAuth(fresh);
    });
  }
}

function setStatus(msg) {
  document.getElementById('statusMsg').textContent = msg;
}

function renderAuth(session) {
  const signedOut = document.getElementById('authSignedOut');
  const signedIn  = document.getElementById('authSignedIn');
  if (session) {
    signedOut.style.display = 'none';
    signedIn.style.display  = 'block';
    document.getElementById('authEmail').textContent       = session.email;
    document.getElementById('authFreeCredits').textContent = `${session.dailyCredits ?? '?'} / 3`;
    document.getElementById('authPaidCredits').textContent = `${session.credits ?? 0}`;
  } else {
    signedOut.style.display = 'flex';
    signedIn.style.display  = 'none';
  }
}

document.getElementById('signInBtn').addEventListener('click', async () => {
  const btn  = document.getElementById('signInBtn');
  const icon = document.querySelector('.ale-hero-icon');
  btn.disabled = true;
  icon.classList.add('brewing');
  const result = await chrome.runtime.sendMessage({ type: 'SIGN_IN' });
  icon.classList.remove('brewing');
  if (result?.error) {
    btn.disabled = false;
    setStatus(result.error);
  } else {
    btn.disabled = false;
    setStatus('');
    renderAuth(result);
  }
});

document.getElementById('signOutBtn').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'SIGN_OUT' });
  renderAuth(null);
});

init();
